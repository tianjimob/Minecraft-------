# 1.18.2-mods-translation-VM-Chinese-tranlate-group
1.18.2的模组翻译请上传到这里
